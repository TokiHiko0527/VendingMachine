[起動方法]
　SampleVendingMachine.exe をダブルクリック

[実行に必要なファイル]
　GUI_File.txt
　SampleVendingMachine.exe
　System_File.txt
　vending_machine.exe

[ログファイル]
　VendingMachineLog.txt